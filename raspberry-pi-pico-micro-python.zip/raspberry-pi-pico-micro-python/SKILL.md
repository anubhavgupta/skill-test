---
name: raspberry-pi-pico-micro-python
description: Comprehensive MicroPython programming for Raspberry Pi Pico. Use when Claude needs to write, explain, or debug MicroPython code that runs on Raspberry Pi Pico. Includes basic programs with GPIO and timers, peripheral programming (ADC, PWM, I2C, SPI, UART), Bluetooth Low Energy applications, multicore programming, and Programmable I/O (PIO) and interrupts.
---

# Raspberry Pi Pico MicroPython

## Overview

This skill provides guidance for writing and understanding MicroPython programs for the Raspberry Pi Pico RP2040 microcontroller. The Pico uses MicroPython, which provides a high-level Python interface to the RP2040's peripherals and hardware features.

## Common Code Patterns

### Basic Structure

Every MicroPython program on Pico typically follows this structure:

```python
from machine import Pin, I2C, SPI, UART, ADC, PWM, Timer

# Initialize peripherals
led = Pin("LED", Pin.OUT)
i2c = I2C(0, scl=Pin(5), sda=Pin(4))
uart = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1))

# Define callback functions
def tick(timer):
    led.toggle()
    # Handle event logic here

# Initialize hardware
tim = Timer()
tim.init(freq=2.5, mode=Timer.PERIODIC, callback=tick)

# Main loop
while True:
    # Your application logic here
    pass
```

### Main Entry Point

Always use the `if __name__ == "__main__":` guard:

```python
def main():
    while True:
        # Your code here
        pass

if __name__ == "__main__":
    main()
```

## Peripheral Programming

### GPIO

```python
from machine import Pin

# Create a GPIO pin
led = Pin("LED", Pin.OUT)
button = Pin(14, Pin.IN, Pin.PULL_DOWN)

# Basic operations
led.on()
led.off()
led.toggle()
value = button.value()
```

### Timers

```python
from machine import Timer

tim = Timer()
tim.init(freq=1, mode=Timer.PERIODIC, callback=tick)

# Timer modes
# - Timer.PERIODIC: Continuous execution
# - Timer.ONE_SHOT: Single execution
```

### PWM

```python
from machine import Pin, PWM

# Create PWM on pin
pwm = PWM(Pin(25))
pwm.freq(1000)  # 1 kHz

# Set duty cycle (0-65535)
pwm.duty_u16(32768)  # 50%

# Fade example
duty = 0
direction = 1
for _ in range(256):
    duty += direction
    if duty > 255:
        duty = 255
        direction = -1
    elif duty < 0:
        duty = 0
        direction = 1
    pwm.duty_u16(duty * duty)
```

### ADC

```python
from machine import ADC

# Create ADC on channel
sensor = ADC(4)

# Read value
value = sensor.read_u16()  # 0-65535

# Read with conversion factor
conversion_factor = 3.3 / 65535
voltage = value * conversion_factor

# Temperature sensor
def get_temperature():
    sensor_temp = ADC(4)
    conversion_factor = 3.3 / 65535
    reading = sensor_temp.read_u16() * conversion_factor
    # Vbe = 0.706V at 27 degrees C, -1.721mV per degree
    temperature = 27 - (reading - 0.706) / 0.001721
    return temperature
```

### I2C

```python
from machine import I2C, Pin

# Initialize I2C
i2c = I2C(0, scl=Pin(5), sda=Pin(4), freq=100000)

# Scan for devices
devices = i2c.scan()
print(devices)  # List of I2C addresses

# Write data
i2c.writeto(0x3C, b'Hello')  # Write to address

# Read data
data = i2c.readfrom(0x3C, 10)  # Read 10 bytes

# Write and read
buf = bytearray(3)
i2c.writeto(0x3C, 'out', buf)
```

### SPI

```python
from machine import SPI

# Initialize SPI
spi = SPI(0, baudrate=100000, polarity=1, phase=1)

# Write data
spi.write('test')

# Read data
data = spi.read(5)

# Write and read
buf = bytearray(3)
spi.write_readinto('out', buf)
```

### UART

```python
from machine import UART

# Initialize UART
uart = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1))

# Write data
uart.write('Hello')

# Read data
if uart.any():
    data = uart.read()
```

### Bluetooth (BLE)

```python
import bluetooth

# Initialize BLE
ble = bluetooth.BLE()

# Simple advertising
payload = bluetooth.advertising_payload(
    name="MyPico",
    services=[bluetooth.UUID(0x181A)]
)
ble.gap_advertise(2000, adv_data=payload)

# For full BLE applications, use:
# - ble_advertising.py helpers for payload generation
# - Central/Peripheral roles for communication
```

## Interrupts

```python
from machine import Pin

# Create pin
pin = Pin(14, Pin.IN)

# Define interrupt callback
def handle_interrupt(pin):
    print("Interrupt triggered!")

# Set interrupt
pin.irq(trigger=Pin.IRQ_FALLING, handler=handle_interrupt)
```

## Multicore Programming

```python
from rp2 import PIO, ASM_PIO, PIOASM_ERROR

# Define a PIO program
@asm_pio(set=2, out_shiftdir=1)
def blink_program():
    set(pins, 1)   # Set pin high
    nop()           # Wait
    set(pins, 0)   # Set pin low
    nop()           # Wait
    nop()           # Wait
    nop()           # Wait

# Initialize PIO
sm = PIO(0)
sm.add_program(blink_program)
sm.exec('set pins, 1')
```

## Debugging Tips

- Use `print()` for debugging (can be slow on Pico)
- Consider `micropython.mem_info()` for memory analysis
- `utime.sleep()` for timing delays
- Check hardware connections and pin assignments
- Verify baud rates match between devices

## Resources

For detailed API reference and more examples, see the [MicroPython Pico API Reference](https://datasheets.raspberrypi.com/pico/raspberry-pi-pico-python-sdk.pdf).
